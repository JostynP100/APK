# Emotional Mangling Proxy
What Apple and I both share after this is done

## What is EMP
A transparent interface level proxy for TCP packets. This project is designed to work around the loopback limitations on iOS.

## How does it work
By modifying packets and retransmitting them back through a WireGuard tunnel

## How to build
``cargo build --target aarch64-apple-ios``

## ETA wen
June 2069